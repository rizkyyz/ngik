--
-- MEMBUAT DATABASE BUKU
-- Database: `db_buku`

CREATE DATABASE db_buku;

-- Bila berhasil kamu dapat melihat database dengan perintah berikut:

SHOW DATABASES;

CREATE TABLE `buku` ( `id` INT(50) NOT NULL AUTO_INCREMENT ,
`judul_buku` VARCHAR(50) NOT NULL , `pengarang` VARCHAR(50) NOT NULL ,
`penerbit` VARCHAR(50) NOT NULL , `harga` INT(50)NOT NULL , `stok` INT(50)
NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `bukumasuk` ( `id_bm` VARCHAR(50) NOT NULL , `id`
INT(50) NOT NULL ,
`tanggal_masuk` DATE NOT NULL , `jumlah` INT(50) NOT NULL ,                                                       
PRIMARY KEY (`id_bm`)) ENGINE =InnoDB;

CREATE TABLE `bukukeluar` ( `id_bk` VARCHAR(50) NOT NULL , `id`
INT(50) NOT NULL ,
`tanggal_keluar` DATE NOT NULL , `jumlah` INT(50) NOT NULL ) ENGINE = InnoDB;